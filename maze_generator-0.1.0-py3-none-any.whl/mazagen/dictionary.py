from typing import Any
from collections.abc import KeysView, ItemsView
from mazagen.utils import get_coord_value
from keys import mandatory_keys


class Dictionary:
    _dictionary: dict[str, Any] = {}

    def __init__(self) -> None:
        pass

    def keys(self) -> KeysView[str]:
        return self._dictionary.keys()

    def items(self) -> ItemsView[str, Any]:
        return self._dictionary.items()

    def add(self, data: list[str]) -> bool:
        if (self._dictionary.get(data[0])):
            return False
        self._dictionary[data[0]] = data[1].strip()
        return True

    def get_width(self) -> int | None:
        key_size: int = len(self._dictionary.keys())
        if key_size == 0 or self._dictionary["WIDTH"] is None:
            return None
        return int(self._dictionary["WIDTH"])

    def get_height(self) -> int | None:
        key_size: int = len(self._dictionary.keys())
        if key_size == 0 or self._dictionary["HEIGHT"] is None:
            return None
        return int(self._dictionary["HEIGHT"])

    def get_entry(self) -> tuple[int, int] | None:
        key_size: int = len(self._dictionary.keys())
        if key_size == 0 or self._dictionary["ENTRY"] is None:
            return None
        tuple_coords = get_coord_value(self._dictionary["ENTRY"])
        return tuple_coords

    def get_exit(self) -> tuple[int, int] | None:
        key_size: int = len(self._dictionary.keys())
        if key_size == 0 or self._dictionary["EXIT"] is None:
            return None
        tuple_coords = get_coord_value(self._dictionary["EXIT"])
        return tuple_coords

    def get_output_file(self) -> str | None:
        key_size: int = len(self._dictionary.keys())
        if key_size == 0 or self._dictionary["OUTPUT_FILE"] is None:
            return None
        return str(self._dictionary["OUTPUT_FILE"])

    def get_is_perfect(self) -> bool | None:
        key_size: int = len(self._dictionary.keys())
        perfect_value: bool = self._dictionary["PERFECT"]
        if key_size == 0 or perfect_value is None:
            return None
        return perfect_value == 'True'

    def check_mandatory_keys_are_in_dict(self) -> bool:
        return all(key in self.keys() for key in mandatory_keys)

    def initial_positions_inside_matrix(self) -> bool:
        entry = self.get_entry()
        exit = self.get_exit()
        width = self.get_width()
        height = self.get_height()

        if (entry is None or exit is None or width is None or height is None):
            return False

        height_entry: int = entry[0]
        width_entry: int = entry[1]

        height_exit: int = exit[0]
        width_exit: int = exit[1]
        return (height_entry >= 0 and height_entry < height and
                width_entry >= 0 and width_entry < width and
                height_exit >= 0 and height_exit < height and
                width_exit >= 0 and width_exit < width)
